/*
 * 士官長工作與壓力助手 - Service Worker (V1.5)
 *
 * 這個 Service Worker 提供最基本的「app shell」離線快取。
 * 注意：Service Worker 需要在 https:// 或 http://localhost 這類「安全來源」
 * 下才會被瀏覽器允許註冊並實際運作。如果你只是用 file:// 直接打開 index.html
 * （例如用 AirDrop 傳到 iPhone 後在 Safari 打開），瀏覽器會略過 Service Worker
 * 註冊（index.html 中已用 try/catch 包起來，不會噴錯），但頁面仍可正常使用，
 * 資料仍會透過 LocalStorage 保存在該次瀏覽的來源中。
 *
 * 若要真正啟用離線快取／完整 PWA 體驗，建議把整個資料夾放到一個簡單的靜態
 * 網站空間（GitHub Pages、Cloudflare Pages、或公司內部網頁伺服器皆可），
 * 用 https 網址開啟並「加入主畫面」。
 */

const CACHE_NAME = 'nco-assistant-v1_5-cache-1';
const APP_SHELL = [
  './index.html',
  './manifest.json',
  './icon-192.png',
  './icon-512.png'
];

self.addEventListener('install', function(event){
  event.waitUntil(
    caches.open(CACHE_NAME).then(function(cache){
      return cache.addAll(APP_SHELL);
    }).catch(function(){
      // 安裝快取失敗時不要讓整個 SW 安裝失敗，避免影響頁面正常使用
      return Promise.resolve();
    })
  );
  self.skipWaiting();
});

self.addEventListener('activate', function(event){
  event.waitUntil(
    caches.keys().then(function(keys){
      return Promise.all(
        keys.filter(function(k){ return k !== CACHE_NAME; })
            .map(function(k){ return caches.delete(k); })
      );
    })
  );
  self.clients.claim();
});

// Cache-first，找不到再回網路；同源請求才處理
self.addEventListener('fetch', function(event){
  if(event.request.method !== 'GET') return;
  const url = new URL(event.request.url);
  if(url.origin !== self.location.origin) return;

  event.respondWith(
    caches.match(event.request).then(function(cached){
      if(cached) return cached;
      return fetch(event.request).then(function(resp){
        if(resp && resp.status===200){
          const respClone = resp.clone();
          caches.open(CACHE_NAME).then(function(cache){ cache.put(event.request, respClone); });
        }
        return resp;
      }).catch(function(){
        // 離線且沒有快取時，對頁面導覽請求退回 index.html
        if(event.request.mode === 'navigate') return caches.match('./index.html');
        return new Response('', { status: 504, statusText: 'Offline' });
      });
    })
  );
});
